# SEN v8 — Render + PostgreSQL + Android

SEN is a communication app with chat, voice/video calls, and a short-video feed.

## What changed in v8
- Replaced the SQLite backend with PostgreSQL using `pg`.
- Added automatic PostgreSQL schema initialization on server startup.
- Added `db/schema.sql` for reference/manual migrations.
- Added a Render Blueprint (`render.yaml`) for the web service + PostgreSQL database.
- Added Render persistent storage for the starter local video uploader.
- Added GitHub Actions to generate the Capacitor Android project and build a test APK.
- Added a GitHub Actions workflow for an Android release AAB build.
- Kept secrets out of source code; use Render/GitHub secret settings.

## Local run
Requirements: Node.js 22+ and PostgreSQL.

```bash
npm install
export DATABASE_URL='postgresql://USER:PASSWORD@HOST:5432/sen'
export DATABASE_SSL='false'
export SEN_JWT_SECRET="$(openssl rand -base64 32)"
npm start
```

Open `http://localhost:3000`.

## Deploy to Render
1. Push this repository to GitHub.
2. In Render, create a **Blueprint** from the repository.
3. Render reads `render.yaml` and creates `sen-api` and `sen-db`.
4. Review the plan/cost before deploying.
5. Add TURN variables for production calling when available.
6. Open the generated HTTPS URL and confirm `/api/health` reports `database: postgresql`.

See `RENDER_POSTGRES.md` for details.

## Android from a phone
You can build a test APK without Android Studio by using GitHub Actions.

1. Push the project to GitHub.
2. Open **Actions** → **Build SEN Android APK** → **Run workflow**.
3. Download the `sen-debug-apk` artifact and install it on your Android phone.

See `ANDROID_FROM_PHONE.md`.

For Google Play, use the release AAB workflow and configure proper app signing. Never commit a keystore or private signing credentials.

## Production video storage
The starter deployment uses a Render persistent disk at `/app/uploads`. This is suitable for an early test deployment, but a large public video platform should move videos to S3-compatible object storage + CDN and use video transcoding/adaptive streaming.

## Environment variables
Start from `.env.example`. Never commit a real `.env` file, JWT secret, database password, Firebase private key, TURN password, or object-storage secret.

## Health endpoint
`GET /api/health`

## Main APIs
- `POST /api/signup`
- `POST /api/login`
- `GET /api/me`
- `GET /api/users`
- `GET /api/messages/:id`
- `POST /api/messages`
- `GET /api/videos/feed`
- `POST /api/videos`
- `POST /api/videos/:id/like`
- `GET /api/videos/:id/comments`
- `POST /api/videos/:id/comments`
- `POST /api/videos/:id/report`
- `DELETE /api/videos/:id`
- `POST /api/users/:id/follow`
- `POST /api/calls`
